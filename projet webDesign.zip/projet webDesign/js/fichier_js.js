/*
commentaire en js sur plusieurs lignes.
*/
// commentaire en js sur une ligne.

//les variables sont de type non défini :
	var myVar = 5;
	myVar = "...";
	myVar = [5,"..."];
	//etc...

// les fonctions peuvent être des variables :
	var myVar = function(){
		// ...
	};

// scope des variables :
	var varA = 2;
	
	var methodA = function(){
		return varA;
	};
	var methodB = function(){
		var varA = 5;
		var methodC = function(){
			return varA;
		};
		return methodC();
	};
	console.log(methodA());	// affiche 2
	console.log(methodB());	// affiche 5

	// -- globals :
	globalA = 5;// déclaration sans utiliser 'var'
	// équivaut à 
	window.globalA = 5;
	
// isoler du code :
	(function(){
		// ...
	})();
